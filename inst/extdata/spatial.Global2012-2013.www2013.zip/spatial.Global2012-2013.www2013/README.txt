The spatial files correspond with the regions used for the Ocean Health Index Global 2013 analysis. These regions are derived from the exclusive economic zones (EEZ) version 7 available through MarineRegions.org.

The unique file / spatial datasets are:

 * eez_rgn_2013master.csv - the lookup table for conversion from EEZ to OHI region

 * rgn_mol.tif - the regions as a raster in the original Mollweide projection used for analysis and area calculations

 * rgn_gcs.tif - the regions as a raster in geographic coordinate system (WGS84) for rendering more easily with other layers

 * rgn_gcs.shp - the regions as a shapefile in geographic coordinate system (WGS84) for vector representation converted from raster. Note that Antarctica was removed from display.

 * rgn_simple_gcs.shp - the regions in geographic coordinate system (WGS84) and simplified (see code with parameters below)

 * rgn_simple_gcs.geojson - the GeoJSON representation of rgn_simple_gcs.shp used by the interactive mapper in the OHI-Science.org application

Please direct technical questions to Ben Best (bbest@nceas.ucsb.edu).


### excerpts from digest_rgn_land_ocean.py for generating rgn_simple_gcs.shp ###
import arcpy

wd      = 'N:/model/GL-NCEAS-OceanRegions_v2013a' # working directory
dd      = wd + '/data'                            # data directory
gdb     = wd + '/geodb.gdb'                       # file geodatabase

arcpy.Dice_management(gdb + 'rgn_gcs',  gdb + 'rgn_gcs_dice10k', '10000')
arcpy.SimplifyPolygon_cartography(gdb+'/rgn_gcs_dice10k', gdb+'/rgn_gcs_dice10k_simplify30km',
                                  'BEND_SIMPLIFY', '30 Kilometers', '0 Unknown', 'NO_CHECK', 'KEEP_COLLAPSED_POINTS')
arcpy.Dissolve_management(gdb+'/rgn_gcs_dice10k_simplify30km', gdb+'/rgn_gcs_dice10k_simplify30km_d', 'rgn_id;rgn_nam')
arcpy.RepairGeometry_management(gdb+'/rgn_gcs_dice10k_simplify30km_d','DELETE_NULL')
arcpy.CopyFeatures_management(gdb+'/rgn_gcs_dice10k_simplify30km_d', dd+'/rgn_simple_gcs.shp')
